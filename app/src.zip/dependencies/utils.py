import yaml
from zipfile import ZipFile 


def load_csv(spark, file_path):
    """
    Read csv files
    :param spark: sparkSession instance
    :param file_path: csv file path
    :return: dataframe
    """
    return spark.read.csv(file_path, header=True, inferSchema=True)

def read_from_yaml(config_path):
    """
    Read YAML file
    :param config_path: path to config.yaml
    :return: dictionary with config details
    """
    with open(config_path, "r") as file:
        return yaml.safe_load(file)
    
def extract_data_from_zip(yaml_config):
    """
    Extract all csv file from Data.zip
    :param file_path: file path to config.yaml
    :return: None
    """
    with ZipFile(yaml_config.get("DATA_ZIP_PATH"), 'r') as f:
        f.extractall()
    

def write_to_parquet(dataframe, result_path):
    """
    Save result in Parquet
    :param dataframe: dataframe
    :param result_path: resultant file path
    :return: None
    """
    dataframe.write.mode("overwrite") \
        .option("header", "true")\
        .parquet(result_path)
